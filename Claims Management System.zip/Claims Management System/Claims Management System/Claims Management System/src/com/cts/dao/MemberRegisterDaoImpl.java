package com.cts.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.servlet.RequestDispatcher;

import com.cts.model.MemberRegisterModel;

public class MemberRegisterDaoImpl {

	public int memberRegister(MemberRegisterModel memberRegModel)
	{
		int result=0;
		 try
		 {  
		 Class.forName("com.mysql.jdbc.Driver");  
		 Connection con=DriverManager.getConnection(  
		 "jdbc:mysql://localhost:3306/dbclaims","root","root");  

		 String sql="insert into tbmemberregister(memberid,firstname,lastname,age,gender,dob,contactnumber,altcontactnumber,emailid,password,plancode,coveragestartdate,coverageenddate,addressline1,city,state,zipcode)values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
		 //String sql="insert into tbregister(adminid,firstname,lastname,age,dob,emailid,password,rpassword)values(?,?,?,?,?,?,?,?,?)";
		 PreparedStatement pstmt=con.prepareStatement(sql);
		 pstmt.setInt(1,memberRegModel.getMemberId());  
		 pstmt.setString(2,memberRegModel.getFirstName());  
		 pstmt.setString(3,memberRegModel.getLastName());  
		 pstmt.setInt(4,memberRegModel.getAge());
		 pstmt.setString(5,memberRegModel.getGender());
		 pstmt.setString(6,memberRegModel.getDoB());
		 pstmt.setString(7,memberRegModel.getContactNumber());  
		 pstmt.setString(8,memberRegModel.getAlt());  
		 pstmt.setString(9,memberRegModel.getEmailID());  
		 pstmt.setString(10,memberRegModel.getPassword()); 
		 pstmt.setString(11,memberRegModel.getPlanCode()); 
		 pstmt.setString(12,memberRegModel.getCoverageStartDate()); 
		 pstmt.setString(13,memberRegModel.getCoverageEndDate()); 
		 pstmt.setString(14,memberRegModel.getAddressLine1()); 
		 pstmt.setString(15,memberRegModel.getCity()); 
		 pstmt.setString(16,memberRegModel.getState()); 
		 pstmt.setInt(17,memberRegModel.getZipCode()); 

		  result=pstmt.executeUpdate();

		
		 }
		 catch(Exception e1)
		 { 
		 System.out.println(e1);
		 }  
		return result;
		
	}
}
