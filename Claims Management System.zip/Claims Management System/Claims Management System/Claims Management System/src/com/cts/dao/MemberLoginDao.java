package com.cts.dao;

import com.cts.model.MemberLoginModel;


public interface MemberLoginDao {

	public String[] memberLogin(MemberLoginModel memberLoginModel);
}
