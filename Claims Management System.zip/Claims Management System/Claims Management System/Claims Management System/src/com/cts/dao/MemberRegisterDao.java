package com.cts.dao;

import com.cts.model.MemberRegisterModel;



public interface MemberRegisterDao {

	public int memberRegister(MemberRegisterModel memberRegModel);
}
