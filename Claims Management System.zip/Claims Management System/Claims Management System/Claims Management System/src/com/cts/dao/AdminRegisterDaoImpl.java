package com.cts.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.servlet.RequestDispatcher;

import com.cts.model.AdminRegisterModel;

public class AdminRegisterDaoImpl implements AdminRegisterDao{

	@Override
	public int adminRegister(AdminRegisterModel adminRegModel) {
		int result = 0;
		try
	     {  
	        Class.forName("com.mysql.jdbc.Driver");  
	        Connection con=DriverManager.getConnection(  
	        "jdbc:mysql://localhost:3306/dbclaims","root","root");  

	        String sql="insert into tbadminregister(adminid,firstname,lastname,age,dob,gender,contactnumber,altcontactnumber,emailid,password,rpassword)values(?,?,?,?,?,?,?,?,?,?,?)";
	        //String sql="insert into register(adminid,firstname,lastname,age,dob,emailid,password,rpassword)values(?,?,?,?,?,?,?,?,?)";
	        PreparedStatement pstmt=con.prepareStatement(sql);
	        pstmt.setInt(1,adminRegModel.getAdminId());  
	        pstmt.setString(2,adminRegModel.getFirstName());  
	        pstmt.setString(3,adminRegModel.getLastName());  
	        pstmt.setInt(4,adminRegModel.getAge());
	        pstmt.setString(5,adminRegModel.getDoB());
	        pstmt.setString(6,adminRegModel.getGender());
	        pstmt.setString(7,adminRegModel.getContactNumber());  
	        pstmt.setString(8,adminRegModel.getAlt());  
	        pstmt.setString(9,adminRegModel.getEmailID());  
	        pstmt.setString(10,adminRegModel.getPassword()); 
	        pstmt.setString(11,adminRegModel.getR_password()); 
	         result=pstmt.executeUpdate();
	        
	        con.close();  
	     }
	     catch(Exception e1)
	     { 
	        System.out.println(e1);
	     }
		return result;  
		
	}

}
