package com.cts.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import com.cts.model.PlanCodeModel;



public class PlanCodeDaoImpl {
	public int planCode(PlanCodeModel planCodeModel)
	{
		int result = 0;
		  try
          {  
          Class.forName("com.mysql.jdbc.Driver");  
             Connection con=DriverManager.getConnection(  
          "jdbc:mysql://localhost:3306/dbclaims","root","root");  

            String sql="insert into tbplancode(plancode,plandescription)values(?,?)";
             //String sql="insert into tbregister(adminid,firstname,lastname,age,dob,emailid,password,rpassword)values(?,?,?,?,?,?,?,?,?)";
             PreparedStatement pstmt=con.prepareStatement(sql);
             pstmt.setString(1,planCodeModel.getPlanCode());  
             pstmt.setString(2,planCodeModel.getPlanDescription());  
             
             result=pstmt.executeUpdate();
             
          }
          catch(Exception e1)
          { 
             System.out.println(e1);
          }  
		return result;
	
	}
}
