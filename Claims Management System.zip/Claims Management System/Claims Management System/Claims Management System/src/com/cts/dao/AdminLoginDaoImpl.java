package com.cts.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;

import com.cts.model.AdminLoginModel;

public class AdminLoginDaoImpl {

	public String adminLogin(AdminLoginModel adminLoginModel)
	{
		String rs2 = null;
		try
	     {  
	     Class.forName("com.mysql.jdbc.Driver");  
	        Connection con=DriverManager.getConnection(  
	     "jdbc:mysql://localhost:3306/dbclaims","root","root");  
	        String sql="select password from tbadminregister  where adminid=?";
	        PreparedStatement pstmt=con.prepareStatement(sql);
	        
	        pstmt.setInt(1,adminLoginModel.getAdminId());  
	        String a2=adminLoginModel.getPassword();
	        java.sql.ResultSet rs= pstmt.executeQuery();
	        while(rs.next())
	        {
	        	rs2=rs.getString(1);
	       // System.out.println(rs.getString(1));
	        }
	        
	     }
	     catch(Exception e1)
	     { 
	        System.out.println(e1);
	     }  
	


		return rs2;
		
	}
}
