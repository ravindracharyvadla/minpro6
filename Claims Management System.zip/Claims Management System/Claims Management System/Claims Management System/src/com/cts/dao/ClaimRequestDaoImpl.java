package com.cts.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import com.cts.model.ClaimRequestModel;

public class ClaimRequestDaoImpl {
	public int claimRequest(ClaimRequestModel claimRequestModel)
	{
		 int result=0;
		try
	     {  
	        Class.forName("com.mysql.jdbc.Driver");  
	        Connection con=DriverManager.getConnection(  
	        "jdbc:mysql://localhost:3306/dbclaims","root","root");  

	        String sql="insert into tbclaimrequest(claimid,memberid,claimservicedate,claimsubmissiondate,claimprocessingdate,claimstatus,claimamount,approvedamount)values(?,?,?,?,?,?,?,?)";
	        //String sql="insert into register(adminid,firstname,lastname,age,dob,emailid,password,rpassword)values(?,?,?,?,?,?,?,?,?)";
	        PreparedStatement pstmt=con.prepareStatement(sql);
	        pstmt.setInt(1,claimRequestModel.getClaimID());  
	        pstmt.setInt(2,claimRequestModel.getMemberID());  
	        pstmt.setString(3,claimRequestModel.getClaimServiceDate());  
	    
	        pstmt.setString(4,claimRequestModel.getClaimSubmissionDate());  
	        pstmt.setString(5,claimRequestModel.getClaimProcessingDate());  
	        pstmt.setString(6,claimRequestModel.getClaimstatus());  
	        pstmt.setInt(7,claimRequestModel.getClaimAmount()); 
	        pstmt.setInt(8,claimRequestModel.getApprovedAmount()); 
	       result=pstmt.executeUpdate();
	        
	     }
	     catch(Exception e1)
	     { 
	        System.out.println(e1);
	     }  
		return result;
		
	}

	
}
