package com.cts.dao;

import com.cts.model.ClaimRequestModel;

public interface ClaimRequestDao {
	public int claimRequest(ClaimRequestModel claimRequestModel);
}
