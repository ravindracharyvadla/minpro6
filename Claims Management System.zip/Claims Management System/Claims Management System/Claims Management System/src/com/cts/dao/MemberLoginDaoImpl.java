package com.cts.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.servlet.RequestDispatcher;

import com.cts.model.MemberLoginModel;

public class MemberLoginDaoImpl {
	public String[] memberLogin(MemberLoginModel memberLoginModel)
	{
		String rs2 = null;
		String rs3= null;
		String [] myArray = new String[2];
	try
	{  
		
	Class.forName("com.mysql.jdbc.Driver");  
	Connection con=DriverManager.getConnection(  
	"jdbc:mysql://localhost:3306/dbclaims","root","root");  
	String sql="select Password,status from tbmemberregister  where memberid=?";
	PreparedStatement pstmt=con.prepareStatement(sql);
	
	
	pstmt.setInt(1,memberLoginModel.getMemberId());  
	java.sql.ResultSet rs= pstmt.executeQuery();
	while(rs.next())
	{
	       rs2=rs.getString(1);
	       rs3=rs.getString(2);
	       
	//System.out.println(rs.getString(1));
	}
	
    myArray[0] = rs2;
    myArray[1] = rs3;
	}
	catch(Exception e1)
	{ 
	System.out.println(e1);
	}  
	return myArray;
	}
}
