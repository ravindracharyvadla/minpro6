package com.cts.dao;

import com.cts.model.PlanCodeModel;

public interface PlanCodeDao {

	public int planCode(PlanCodeModel planCodeModel);
}
