package com.cts.dao;

import com.cts.model.AdminRegisterModel;

public interface AdminRegisterDao {

	public int adminRegister(AdminRegisterModel adminRegModel);
}
