package com.cts.dao;

import com.cts.model.AdminLoginModel;


public interface AdminLoginDao {

	public String adminLogin(AdminLoginModel adminLoginModel);
}
