package com.cts.service;

import com.cts.dao.AdminLoginDao;
import com.cts.dao.AdminLoginDaoImpl;
import com.cts.dao.MemberLoginDao;
import com.cts.dao.MemberLoginDaoImpl;
import com.cts.model.MemberLoginModel;

public class MemberLoginServiceImpl implements MemberLoginDao {
	MemberLoginDaoImpl memberLoginDaoImpl;
	@Override
	public String[] memberLogin(MemberLoginModel memberLoginModel)
	{
		memberLoginDaoImpl=new MemberLoginDaoImpl();
		return memberLoginDaoImpl.memberLogin(memberLoginModel);
		
	}
}
