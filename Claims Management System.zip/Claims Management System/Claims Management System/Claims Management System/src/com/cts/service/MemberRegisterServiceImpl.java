package com.cts.service;

import com.cts.dao.AdminRegisterDao;
import com.cts.dao.AdminRegisterDaoImpl;
import com.cts.dao.MemberRegisterDao;
import com.cts.dao.MemberRegisterDaoImpl;
import com.cts.model.MemberRegisterModel;

public class MemberRegisterServiceImpl implements MemberRegisterDao {
	MemberRegisterDaoImpl memberRegDaoImpl;
	@Override
	public int memberRegister(MemberRegisterModel memberRegModel)
	{
		memberRegDaoImpl=new MemberRegisterDaoImpl();
		return memberRegDaoImpl.memberRegister(memberRegModel);
		
	}
}
