package com.cts.service;

import com.cts.model.AdminRegisterModel;

public interface AdminRegisterService {

	public int adminRegister(AdminRegisterModel adminRegModel);
}
