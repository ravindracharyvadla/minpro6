package com.cts.service;

import com.cts.model.ClaimRequestModel;

public interface ClaimRequestService {

	public int claimRequest(ClaimRequestModel claimRequestModel);
}
