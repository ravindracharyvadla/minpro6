package com.cts.service;

import com.cts.dao.AdminLoginDao;
import com.cts.dao.AdminLoginDaoImpl;
import com.cts.dao.AdminRegisterDaoImpl;
import com.cts.model.AdminLoginModel;

public class AdminLoginServiceImpl implements AdminLoginDao{

	AdminLoginDaoImpl adminLoginDaoImpl;
	@Override
	public String adminLogin(AdminLoginModel adminLoginModel)
	{
		adminLoginDaoImpl=new AdminLoginDaoImpl();
		return adminLoginDaoImpl.adminLogin(adminLoginModel);
		
	}
}
