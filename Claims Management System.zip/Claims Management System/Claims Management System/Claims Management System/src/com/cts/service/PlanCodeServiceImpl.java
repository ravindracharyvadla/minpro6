package com.cts.service;

import com.cts.dao.AdminRegisterDao;
import com.cts.dao.AdminRegisterDaoImpl;
import com.cts.dao.PlanCodeDao;
import com.cts.dao.PlanCodeDaoImpl;
import com.cts.model.PlanCodeModel;

public class PlanCodeServiceImpl implements PlanCodeDao{

	PlanCodeDaoImpl planCodeDaoImpl;
	@Override
	public int planCode(PlanCodeModel planCodeModel)
	{
		planCodeDaoImpl=new PlanCodeDaoImpl();
		return planCodeDaoImpl.planCode(planCodeModel);
	}
}
