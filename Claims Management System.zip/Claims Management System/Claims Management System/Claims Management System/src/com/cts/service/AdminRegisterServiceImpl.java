package com.cts.service;

import com.cts.dao.AdminRegisterDao;
import com.cts.dao.AdminRegisterDaoImpl;
import com.cts.model.AdminRegisterModel;
import com.sun.org.glassfish.gmbal.AMXMBeanInterface;

public class AdminRegisterServiceImpl implements AdminRegisterDao{

	AdminRegisterDaoImpl adminRegDaoImpl;
	@Override
	public int adminRegister(AdminRegisterModel adminRegModel) {
		adminRegDaoImpl=new AdminRegisterDaoImpl();
		return adminRegDaoImpl.adminRegister(adminRegModel);
	}

}
