package com.cts.service;

import com.cts.model.AdminLoginModel;

public interface AdminLoginService {

	public String adminLogin(AdminLoginModel adminLoginModel);
}
