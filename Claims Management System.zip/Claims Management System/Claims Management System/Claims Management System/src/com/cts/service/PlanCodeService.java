package com.cts.service;

import com.cts.model.PlanCodeModel;

public interface PlanCodeService {

	public int planCode(PlanCodeModel planCodeModel);
}
