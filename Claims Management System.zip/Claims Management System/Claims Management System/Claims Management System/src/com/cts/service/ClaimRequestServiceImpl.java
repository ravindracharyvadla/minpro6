package com.cts.service;

import com.cts.dao.AdminRegisterDao;
import com.cts.dao.AdminRegisterDaoImpl;
import com.cts.dao.ClaimRequestDao;
import com.cts.dao.ClaimRequestDaoImpl;
import com.cts.model.ClaimRequestModel;

public class ClaimRequestServiceImpl implements ClaimRequestDao{

	ClaimRequestDaoImpl claimRequestDaoImpl;
	@Override
	public int claimRequest(ClaimRequestModel claimRequestModel)
	{
		claimRequestDaoImpl=new ClaimRequestDaoImpl ();
		return claimRequestDaoImpl.claimRequest(claimRequestModel);
	}
	
}
