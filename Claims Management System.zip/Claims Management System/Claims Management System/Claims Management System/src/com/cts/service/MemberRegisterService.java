package com.cts.service;

import com.cts.model.MemberRegisterModel;

public interface MemberRegisterService {

	public int memberRegister(MemberRegisterModel memberRegModel);
}
