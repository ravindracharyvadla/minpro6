package com.cts.service;

import com.cts.model.MemberLoginModel;

public interface MemberLoginService {

	public String[] memberLogin(MemberLoginModel memberLoginModel);
}
