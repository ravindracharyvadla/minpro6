package com.cts.model;

public class MemberLoginModel {

	private int MemberId;  
   private  String Password;
public int getMemberId() {
	return MemberId;
}
public void setMemberId(int memberId) {
	MemberId = memberId;
}
public String getPassword() {
	return Password;
}
public void setPassword(String password) {
	Password = password;
}
   
}
