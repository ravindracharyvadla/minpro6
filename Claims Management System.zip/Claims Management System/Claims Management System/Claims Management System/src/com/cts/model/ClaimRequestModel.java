package com.cts.model;

public class ClaimRequestModel {
	private int claimID;  
	private int memberID;  
	private String claimServiceDate;  
	
	private String claimSubmissionDate;
	private String claimProcessingDate;
	private String claimstatus;
	private int claimAmount;
	private int approvedAmount;
	public int getClaimID() {
		return claimID;
	}
	public void setClaimID(int claimID) {
		this.claimID = claimID;
	}
	public int getMemberID() {
		return memberID;
	}
	public void setMemberID(int memberID) {
		this.memberID = memberID;
	}
	public String getClaimServiceDate() {
		return claimServiceDate;
	}
	public void setClaimServiceDate(String claimServiceDate) {
		this.claimServiceDate = claimServiceDate;
	}
	public String getClaimSubmissionDate() {
		return claimSubmissionDate;
	}
	public void setClaimSubmissionDate(String claimSubmissionDate) {
		this.claimSubmissionDate = claimSubmissionDate;
	}
	public String getClaimProcessingDate() {
		return claimProcessingDate;
	}
	public void setClaimProcessingDate(String claimProcessingDate) {
		this.claimProcessingDate = claimProcessingDate;
	}
	public String getClaimstatus() {
		return claimstatus;
	}
	public void setClaimstatus(String claimstatus) {
		this.claimstatus = claimstatus;
	}
	public int getClaimAmount() {
		return claimAmount;
	}
	public void setClaimAmount(int claimAmount) {
		this.claimAmount = claimAmount;
	}
	public int getApprovedAmount() {
		return approvedAmount;
	}
	public void setApprovedAmount(int approvedAmount) {
		this.approvedAmount = approvedAmount;
	}
	
	
}
