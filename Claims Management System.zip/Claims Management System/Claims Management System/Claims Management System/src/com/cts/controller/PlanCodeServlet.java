package com.cts.controller;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cts.dao.MemberRegisterDaoImpl;
import com.cts.dao.PlanCodeDaoImpl;
import com.cts.model.MemberRegisterModel;
import com.cts.model.PlanCodeModel;
import com.cts.service.AdminRegisterServiceImpl;
import com.cts.service.PlanCodeServiceImpl;

@WebServlet("/PlanCodeServlet")
public class PlanCodeServlet extends HttpServlet {
       private static final long serialVersionUI= 1L;
       protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
              response.setContentType("text/html");
              PrintWriter out=response.getWriter();
              String n=request.getParameter("planCode");  
              String p=request.getParameter("planDescription");  
              PlanCodeServiceImpl planCodeServiceImpl=new PlanCodeServiceImpl();
              PlanCodeModel planCodeModel=new PlanCodeModel();
              planCodeModel.setPlanCode(n);
              planCodeModel.setPlanDescription(p);
              
              int i=planCodeServiceImpl.planCode(planCodeModel);
              
              if(i>0)
              {
                 System.out.println("Record Inserted");
              }
              else
              {
                 System.out.println("Not Record Inserted");
              }
              
            
       }


}

