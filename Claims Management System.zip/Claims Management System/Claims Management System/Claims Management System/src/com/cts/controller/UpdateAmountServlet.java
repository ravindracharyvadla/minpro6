package com.cts.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.mysql.jdbc.Connection;


@WebServlet("/UpdateAmountServlet")
public class UpdateAmountServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
   
	
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
        int a=Integer.parseInt(request.getParameter("ClaimAmount"));
		//out.println(a);
		int b=Integer.parseInt(request.getParameter("ApprovedAmount"));
		//out.println(b);
		HttpSession session =request.getSession();
        int c=(int) session.getAttribute("a");
       // out.println(c);
		try
	     {  
	        Class.forName("com.mysql.jdbc.Driver");  
	        Connection con=(Connection) DriverManager.getConnection(  
	        "jdbc:mysql://localhost:3306/dbclaims","root","root"); 
	        
	        String sql="update tbclaimrequest set claimamount=?,approvedamount=? where claimid=?";
	        
	        //String sql="insert into register(adminid,firstname,lastname,age,dob,emailid,password,rpassword)values(?,?,?,?,?,?,?,?,?)";
	        PreparedStatement pstmt=con.prepareStatement(sql);
	        pstmt.setInt(1, a);
	        pstmt.setInt(2, b);
	        pstmt.setInt(3, c);
	        int i=pstmt.executeUpdate();
	        if(i>0)
	        {
	        	out.println("Amount Updated");
	        }
	        con.close();  
	     }
	     catch(Exception e1)
	     { 
	        System.out.println(e1);
	     }  

	}

}
