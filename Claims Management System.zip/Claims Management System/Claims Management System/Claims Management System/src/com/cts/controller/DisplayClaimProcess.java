package com.cts.controller;
import java.sql.*;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.DriverManager;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.sql.PreparedStatement;


@WebServlet("/DisplayClaimProcess")
public class DisplayClaimProcess extends HttpServlet {
       private static final long serialVersionUID = 1L;
    
       protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException,NumberFormatException, IOException {
              response.setContentType("text/html");
        PrintWriter out=response.getWriter();
        int n=Integer.parseInt(request.getParameter("btn"));  
       
        
        try
{  
Class.forName("com.mysql.jdbc.Driver");  
Connection con=(Connection) DriverManager.getConnection(  
"jdbc:mysql://localhost:3306/dbclaims","root","root");  

//String sql="insert into tbclaimsrequest(claimID,MemberID,ClaimServiceDate,ClaimSubmissionDate,ClaimProcessingDate,ClaimsStatus,ClaimAmount,ApprovedAmount)values(?,?,?,?,?,?,?,?)";
String sql1="select * from tbclaimrequest where claimid=?";
PreparedStatement pstmt=con.prepareStatement(sql1);
pstmt.setInt(1,n);  
out.print("<table width=25% border=1>");

out.print("<center><h1>CLAIM DETAILS:</h1></center>");

ResultSet rs=pstmt.executeQuery();                



ResultSetMetaData rsmd=rs.getMetaData();

while(rs.next())

   {

out.print("<tr>");

out.print("<td>"+rsmd.getColumnName(1)+"</td>");

   out.print("<td>"+rs.getInt(1)+"</td></tr>");

   out.print("<tr><td>"+rsmd.getColumnName(2)+"</td>");

   out.print("<td>"+rs.getInt(2)+"</td></tr>");

   out.print("<tr><td>"+rsmd.getColumnName(3)+"</td>");

   out.print("<td>"+rs.getString(3)+"</td></tr>");

   out.print("<tr><td>"+rsmd.getColumnName(4)+"</td>");

   out.print("<td>"+rs.getString(4)+"</td></tr>"); 
   out.print("<tr><td>"+rsmd.getColumnName(5)+"</td>");

   out.print("<td>"+rs.getString(5)+"</td></tr>");

   out.print("<tr><td>"+rsmd.getColumnName(6)+"</td>");

   out.print("<td>"+rs.getString(6)+"</td></tr>"); 
   out.print("<tr><td>"+rsmd.getColumnName(7)+"</td>");

   out.print("<td>"+rs.getInt(7)+"</td></tr>");

   out.print("<tr><td>"+rsmd.getColumnName(8)+"</td>");

   out.print("<td>"+rs.getInt(8)+"</td></tr>"); 

}
out.print("</table>");



con.close();  
}
catch(Exception e1)
{ 
System.out.println(e1);
}  
}




}

