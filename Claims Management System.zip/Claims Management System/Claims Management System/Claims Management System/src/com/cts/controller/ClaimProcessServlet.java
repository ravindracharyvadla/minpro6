package com.cts.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.mysql.jdbc.Connection;


@WebServlet("/ClaimProcessServlet")
public class ClaimProcessServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
    
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		String n=null;

		try
	     {  
	        Class.forName("com.mysql.jdbc.Driver");  
	        Connection con=(Connection) DriverManager.getConnection(  
	        "jdbc:mysql://localhost:3306/dbclaims","root","root");  

	        String sql="select claimid,claimstatus from tbclaimrequest";
	        //String sql="insert into register(adminid,firstname,lastname,age,dob,emailid,password,rpassword)values(?,?,?,?,?,?,?,?,?)";
	        PreparedStatement pstmt=con.prepareStatement(sql);
	       
	        java.sql.ResultSet rs= pstmt.executeQuery();
	        RequestDispatcher rd=request.getRequestDispatcher("claimProcess.html");
	        rd.include(request, response);

	        int rs2 = 0;
	        String rs3=null;
	        out.println("<html><head><title>claim id</title></head><body>");
	       out.println("<form action=showClaimServlet>");
	        while(rs.next())
	        {
	        	rs2=rs.getInt(1);
	        	rs3=rs.getString(2);
	        	if(rs3.equals("Submitted"))
	        	{
	        	 out.println("<input type=submit name=btn value="+rs2+"></input>");
	        	 
	        	 out.println("<br>");
	        	 //request.setAttribute("memberid",rs2);
	        	 String a = null;
	        	 
				
	        	}
	       // System.out.println(rs.getString(1));
	        }
	        out.println("</form></body></html>");
	        con.close();  
	     }
	     catch(Exception e1)
	     { 
	        System.out.println(e1);
	     }  
	}

}
