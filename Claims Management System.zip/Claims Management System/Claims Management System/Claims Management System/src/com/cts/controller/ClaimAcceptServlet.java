package com.cts.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


@WebServlet("/ClaimAcceptServlet")
public class ClaimAcceptServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
	String n=request.getParameter("btn");
	
		try
	     {  
	        Class.forName("com.mysql.jdbc.Driver");  
	        Connection con=DriverManager.getConnection(  
	        "jdbc:mysql://localhost:3306/dbclaims","root","root");  
	       
	        HttpSession session = request.getSession();
			int b= (int) session.getAttribute("a"); 
		//	out.println(b);
	      
	       String sql;
	       if(n.equals("Accept"))
	       {
	        sql="update tbclaimrequest set claimstatus='Accepted' where claimid=?" ;
	       // out.println("Accepted");
	        RequestDispatcher rd=request.getRequestDispatcher("UpdateAmount.html");
	        rd.include(request, response);

	       
	        
	       }
	       else
	       {
	    	    sql="update tbclaimrequest set claimstatus='Denied' where claimid=?" ;
	    	  //  out.println("Rejected");
	    	    
	       }
	       
	        //String sql="insert into register(adminid,firstname,lastname,age,dob,emailid,password,rpassword)values(?,?,?,?,?,?,?,?,?)";
	        PreparedStatement pstmt=con.prepareStatement(sql);
	        pstmt.setInt(1,b);  
	        int i=pstmt.executeUpdate();
	        con.close();  
	     }
	     catch(Exception e1)
	     { 
	        System.out.println(e1);
	     }  
	}
}
