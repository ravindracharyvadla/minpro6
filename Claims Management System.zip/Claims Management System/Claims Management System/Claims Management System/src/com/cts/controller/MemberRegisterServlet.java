package com.cts.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cts.dao.AdminRegisterDaoImpl;
import com.cts.dao.MemberRegisterDaoImpl;
import com.cts.model.AdminRegisterModel;
import com.cts.model.MemberRegisterModel;
import com.cts.service.AdminRegisterServiceImpl;
import com.cts.service.MemberRegisterServiceImpl;


@WebServlet("/MemberRegisterServlet")
public class MemberRegisterServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
        PrintWriter out=response.getWriter();
        int n=Integer.parseInt(request.getParameter("memberId"));  
        String p=request.getParameter("firstName");  
        String e=request.getParameter("lastName");  
        int c=Integer.parseInt(request.getParameter("age"));  
        String g=request.getParameter("gender");
        String a=request.getParameter("doB");
        String b=request.getParameter("contactNumber");
        String b1=request.getParameter("alt");
        String a1=request.getParameter("emailID");
        String a2=request.getParameter("password");
        String a3=request.getParameter("planCode");
        String a4=request.getParameter("coverageStartDate");
        String a5=request.getParameter("coverageEndDate");
        String a6=request.getParameter("addressLine1");
        String a7=request.getParameter("city");
        String a8=request.getParameter("state");
           int b2=Integer.parseInt(request.getParameter("zipCode"));
           
           MemberRegisterServiceImpl memberRegisterServiceImpl=new MemberRegisterServiceImpl();
           MemberRegisterModel memberRegModel=new MemberRegisterModel();
           memberRegModel.setMemberId(n);
           memberRegModel.setFirstName(p);
           memberRegModel.setLastName(e);
           memberRegModel.setAge(c);
           memberRegModel.setGender(g);
           memberRegModel.setDoB(a);
           memberRegModel.setContactNumber(b);
   		
           memberRegModel.setAlt(b1);
           memberRegModel.setEmailID(a1);
           memberRegModel.setPassword(a2);
           memberRegModel.setPlanCode(a3);
           memberRegModel.setCoverageEndDate(a5);           
           memberRegModel.setCoverageStartDate(a4);
           memberRegModel.setAddressLine1(a6);
           memberRegModel.setCity(a7);
           memberRegModel.setState(a8);
           memberRegModel.setZipCode(b2);
          
   		int i=memberRegisterServiceImpl.memberRegister(memberRegModel);
   		if(i>0)
           {
              System.out.println("Your details are submitted successfully�.");
              //out.print("Your details are submitted successfully.");
              RequestDispatcher rd=request.getRequestDispatcher("AdminLogin.html");  
               rd.include(request, response);  
           }
           else
           {
              System.out.println("Not Record Inserted");
           }
   		
        
       
	}

}
