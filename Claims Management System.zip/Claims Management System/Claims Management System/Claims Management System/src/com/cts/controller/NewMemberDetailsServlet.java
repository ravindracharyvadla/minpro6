package com.cts.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mysql.jdbc.Connection;


@WebServlet("/NewMemberDetailsServlet")
public class NewMemberDetailsServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
        PrintWriter out=response.getWriter();
        int n=Integer.parseInt(request.getParameter("btn"));  
       
        try
{  
Class.forName("com.mysql.jdbc.Driver");  
Connection con=(Connection) DriverManager.getConnection(  
"jdbc:mysql://localhost:3306/dbclaims","root","root");  

//String sql="insert into tbclaimsrequest(claimID,MemberID,ClaimServiceDate,ClaimSubmissionDate,ClaimProcessingDate,ClaimsStatus,ClaimAmount,ApprovedAmount)values(?,?,?,?,?,?,?,?)";
String sql1="select * from tbmemberregister where memberid=?";
PreparedStatement pstmt=con.prepareStatement(sql1);
pstmt.setInt(1,n);  
out.print("<table width=25% border=1>");

out.print("<center><h1>CLAIM DETAILS:</h1></center>");

ResultSet rs=pstmt.executeQuery();                

/* Printing column names */

ResultSetMetaData rsmd=rs.getMetaData();

while(rs.next())

   {

out.print("<tr>");

out.print("<td>"+rsmd.getColumnName(1)+"</td>");

   out.print("<td>"+rs.getString(1)+"</td></tr>");

   out.print("<tr><td>"+rsmd.getColumnName(2)+"</td>");

   out.print("<td>"+rs.getString(2)+"</td></tr>");

   out.print("<tr><td>"+rsmd.getColumnName(3)+"</td>");

   out.print("<td>"+rs.getString(3)+"</td></tr>");

   out.print("<tr><td>"+rsmd.getColumnName(4)+"</td>");

   out.print("<td>"+rs.getInt(4)+"</td></tr>"); 
   out.print("<tr><td>"+rsmd.getColumnName(5)+"</td>");

   out.print("<td>"+rs.getString(5)+"</td></tr>");

   out.print("<tr><td>"+rsmd.getColumnName(6)+"</td>");

   out.print("<td>"+rs.getString(6)+"</td></tr>"); 
   out.print("<tr><td>"+rsmd.getColumnName(7)+"</td>");

   out.print("<td>"+rs.getString(7)+"</td></tr>");

   out.print("<tr><td>"+rsmd.getColumnName(8)+"</td>");
   out.print("<td>"+rs.getString(8)+"</td></tr>"); 

  
   out.print("<tr><td>"+rsmd.getColumnName(9)+"</td>");
   out.print("<td>"+rs.getString(9)+"</td></tr>"); 
   
   out.print("<tr><td>"+rsmd.getColumnName(10)+"</td>");
   out.print("<td>"+rs.getString(10)+"</td></tr>"); 
   
   out.print("<tr><td>"+rsmd.getColumnName(11)+"</td>");
   out.print("<td>"+rs.getString(11)+"</td></tr>"); 
   
   out.print("<tr><td>"+rsmd.getColumnName(12)+"</td>");
   out.print("<td>"+rs.getString(12)+"</td></tr>"); 
   
   out.print("<tr><td>"+rsmd.getColumnName(13)+"</td>");
   out.print("<td>"+rs.getString(13)+"</td></tr>"); 
   
   out.print("<tr><td>"+rsmd.getColumnName(14)+"</td>");
   out.print("<td>"+rs.getString(14)+"</td></tr>"); 
   
   out.print("<tr><td>"+rsmd.getColumnName(15)+"</td>");
   out.print("<td>"+rs.getString(15)+"</td></tr>"); 
   
   out.print("<tr><td>"+rsmd.getColumnName(16)+"</td>");
   out.print("<td>"+rs.getString(16)+"</td></tr>"); 
   
   out.print("<tr><td>"+rsmd.getColumnName(17)+"</td>");
   out.print("<td>"+rs.getInt(17)+"</td></tr>"); 
   
}

out.print("</table>");

RequestDispatcher rd=request.getRequestDispatcher("AcceptOrRejectMember.html");  
rd.include(request, response);  

con.close();  
}
catch(Exception e1)
{ 
System.out.println(e1);
}  
}




}

