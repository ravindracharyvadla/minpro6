package com.cts.controller;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cts.dao.AdminRegisterDaoImpl;
import com.cts.model.AdminRegisterModel;
import com.cts.service.AdminRegisterServiceImpl;


@WebServlet("/AdminRegisterServlet")
public class AdminRegisterServlet extends HttpServlet 
{
	private static final long serialVersionUID = 1L;
       
 

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException,NumberFormatException
	{
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		int n=Integer.parseInt(request.getParameter("adminId"));  
		String p=request.getParameter("firstName");  
		String e=request.getParameter("lastName");  
		int c=Integer.parseInt(request.getParameter("age"));  
		String a=request.getParameter("doB");
	    String g=request.getParameter("gender");
		String b=request.getParameter("contactNumber");
	    String b1=request.getParameter("alt");
		String a1=request.getParameter("emailID");
		String a2=request.getParameter("password");
		String a3=request.getParameter("r_password");
		
		//AdminRegisterDaoImpl adminregdaoimpl=new AdminRegisterDaoImpl();
		AdminRegisterServiceImpl adminRegisterServiceImpl=new AdminRegisterServiceImpl();
		AdminRegisterModel adminRegModel=new AdminRegisterModel();
		adminRegModel.setAdminId(n);
		adminRegModel.setFirstName(p);
		adminRegModel.setLastName(e);
		adminRegModel.setAge(c);
		adminRegModel.setDoB(a);
		adminRegModel.setGender(g);
		adminRegModel.setContactNumber(b);
		
		adminRegModel.setAlt(b1);
		adminRegModel.setEmailID(a1);
		adminRegModel.setPassword(a2);
		adminRegModel.setR_password(a3);;
		int i=adminRegisterServiceImpl.adminRegister(adminRegModel);
		if(i>0)
        {
           System.out.println("Your details are submitted successfully�.");
           //out.print("Your details are submitted successfully.");
           RequestDispatcher rd=request.getRequestDispatcher("AdminLogin.html");  
            rd.include(request, response);  
        }
        else
        {
           System.out.println("Not Record Inserted");
        }
		
	}

}

