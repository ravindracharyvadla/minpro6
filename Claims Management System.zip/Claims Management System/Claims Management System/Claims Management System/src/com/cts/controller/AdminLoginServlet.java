package com.cts.controller;


import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cts.dao.AdminLoginDaoImpl;
import com.cts.dao.AdminRegisterDaoImpl;
import com.cts.model.AdminLoginModel;
import com.cts.model.AdminRegisterModel;
import com.cts.service.AdminLoginServiceImpl;
import com.cts.service.AdminRegisterServiceImpl;
import com.mysql.jdbc.ResultSet;
import com.mysql.jdbc.Statement;

@WebServlet("/AdminLoginServlet")
public class AdminLoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		int n=Integer.parseInt(request.getParameter("AdminId"));  
		String a2=request.getParameter("Password");
//System.out.println(n);
		AdminLoginServiceImpl adminLoginServiceImpl=new AdminLoginServiceImpl();
		AdminLoginModel adminloginModel=new AdminLoginModel();
		adminloginModel.setAdminId(n);
		adminloginModel.setPassword(a2);
		
		String rs2=adminLoginServiceImpl.adminLogin(adminloginModel);
		if(rs2.equals(a2))
        {
        	System.out.println("Login Successfull");
        	
			RequestDispatcher rd=(request).getRequestDispatcher("AdminHome.html");  
            
			rd.include(request, response);  
        }
        else 
        {
        	System.out.println("Login Unsuccessfull");
        }
        
		


	}

}
