package com.cts.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cts.dao.AdminRegisterDaoImpl;
import com.cts.dao.ClaimRequestDaoImpl;
import com.cts.model.AdminRegisterModel;
import com.cts.model.ClaimRequestModel;
import com.cts.service.AdminRegisterServiceImpl;
import com.cts.service.ClaimRequestServiceImpl;


@WebServlet("/ClaimRequestServlet")
public class ClaimRequestServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
   
	
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		int n=Integer.parseInt(request.getParameter("claimID"));  
		int p=Integer.parseInt(request.getParameter("memberID"));  
		String e=request.getParameter("claimServiceDate");  
		
		String b=request.getParameter("claimSubmissionDate");
	    String b1=request.getParameter("claimProcessingDate");
		String a1=request.getParameter("claimstatus");
		int a2=Integer.parseInt(request.getParameter("claimAmount"));
		int a3=Integer.parseInt(request.getParameter("approvedAmount"));
		
		ClaimRequestServiceImpl claimRequestServiceImpl=new ClaimRequestServiceImpl();
		ClaimRequestModel claimRequestModel=new ClaimRequestModel();
		claimRequestModel.setClaimID(n);
		claimRequestModel.setMemberID(p);
		claimRequestModel.setClaimServiceDate(e);
		claimRequestModel.setClaimSubmissionDate(b);
		claimRequestModel.setClaimProcessingDate(b1);
		claimRequestModel.setClaimstatus(a1);
		claimRequestModel.setClaimAmount(a2);
		
		claimRequestModel.setApprovedAmount(a3);
		
		int i=claimRequestServiceImpl.claimRequest(claimRequestModel);
		 if(i>0)
	        {
	           System.out.println("Your details are submitted successfully�.");
	        }
	        else
	        {
	           System.out.println("Not Record Inserted");
	        }
	        
		
	}

}
