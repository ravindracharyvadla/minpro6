package com.cts.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.DriverManager;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.PreparedStatement;

/**
 * Servlet implementation class DisplayStatusServlet
 */
@WebServlet("/DisplayStatusServlet")
public class DisplayStatusServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html");
        PrintWriter out=response.getWriter();   
        try
{  
Class.forName("com.mysql.jdbc.Driver");  
Connection con=(Connection) DriverManager.getConnection(  
"jdbc:mysql://localhost:3306/dbclaims","root","root");  

//String sql="insert into tbdetails(claimID,MemberID,ClaimServiceDate,ClaimSubmissionDate,ClaimProcessingDate,ClaimsStatus,ClaimAmount,ApprovedAmount)values(?,?,?,?,?,?,?,?)";
String sql1="select claimid from tbclaimrequest where memberid=?";
PreparedStatement pstmt= (PreparedStatement) con.prepareStatement(sql1);


HttpSession session = request.getSession();
int c= (int) session.getAttribute("x"); 

pstmt.setInt(1,c); 
java.sql.ResultSet rs= pstmt.executeQuery();
RequestDispatcher rd=request.getRequestDispatcher("ClaimDetails.html");
rd.include(request, response);
out.println("<html><head><title>claim id</title></head><body>");
out.println("<form action=DisplayClaimProcess>");
while(rs.next())
{
       int rs2 = rs.getInt(1);
       out.println("<input type=submit name=btn value="+rs2+"></input>");
       
      out.println("<br>");
     // out.println(rs2);
//out.println(rs2);
}
out.println("</form></body></html>");

con.close();  
}
catch(Exception e1)
{ 
System.out.println(e1);
} 

       }

}
