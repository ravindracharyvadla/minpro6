

function formValidation() {
	var id = document.registration.adminId;
	var fname = document.registration.firstName;
	var lname = document.registration.lastName;
	var age = document.registration.age;
	var gender = document.registration.gender;
	var dob = document.registration.doB;
	var contact = document.registration.contactNumber;
	var altercontact = document.registration.alt;
	var email = document.registration.emailID; 
	var pass = document.registration.password; 
	var rpass = document.registration.r_password; 
	//alert("hi");
	var count;
	count=0;
	var check;
	
	
	
	check=/^[0-9]+$/;
	if (id.value.match(check))
	{
	}
	else
	{
	//alert("AdminId should contains Number");
	//fname.focus();
		id.style.borderColor="red";
		id.style.borderWidth="2px";
	count=count+1;
	//return false;
	}
	
	
	
	
	check=/^[A-Za-z]+$/;
	if (fname.value.match(check))
	{

	}
	else
	{
	//alert("First name should contains character");
	//fname.focus();
		fname.style.borderColor="red";
		fname.style.borderWidth="2px";
	count=count+1;
	//return false;
	}
	
	
	
	
	check=/^[A-Za-z0-9]+$/;
	if (pass.value.match(check))
	{
	}
	else
	{
	//alert("First name should contains character");
	//fname.focus();
		pass.style.borderColor="red";
		pass.style.borderWidth="2px";
	count=count+1;
	//return false;
	}
	
	check=/^[A-Za-z0-9]+$/;
	if (rpass.value.match(check))
	{
	}
	else
	{
	//alert("First name should contains character");
	//fname.focus();
		rpass.style.borderColor="red";
		rpass.style.borderWidth="2px";
	count=count+1;
	//return false;
	}
	
	
	
	
	check=/^[A-Za-z]+$/;
	if (gender.value.match(check))
	{
	}
	else
	{
	//alert("First name should contains character");
	//fname.focus();
		gender.style.borderColor="red";
		gender.style.borderWidth="2px";
	count=count+1;
	//return false;
	}
	
	
	check=/^([0-9]{2})\/([0-9]{2})\/([0-9]{4})$/;
	if (dob.value.match(check))
	{
	}
	else
	{
	//alert("First name should contains character");
	//fname.focus();
		dob.style.borderColor="red";
		dob.style.borderWidth="2px";
	count=count+1;
	//return false;
	}
	
	

	check=/^[A-Za-z]+$/;
	if (lname.value.match(check))
	{
	       //return true;
	}
	else
	{
	//alert("Last name should contains character");
	//lname.focus();
		lname.style.borderColor="red";
		lname.style.borderWidth="2px";
	       count=count+1;
	//return false;
	}

	check=/^[0-9]{2}$/;
	if (age.value.match(check))
	{
	       //return true;
	}
	else
	{
	//alert("Age must contain number");
	//age.focus();
		age.style.borderColor="red";
		age.style.borderWidth="2px";
	       count=count+1;
	//return false;
	}

	check=/^[0-9]+$/;
	if (contact.value.match(check))
	{
	       //return true;
		//document.write(contact.length);
	}
	
	else
	{
	
	//num.focus();
		//alert("Contact must contain number");
	       contact.style.borderColor="red";
	      contact.style.borderWidth="2px";
	       count=count+1;
	//return false;
	}


	check=/^[0-9]+$/;
	if (altercontact.value.match(check))
	{
	       //return true;
	}
	else
	{
	//alert("Alternate Contact must contain number");
	//anum.focus();
		altercontact.style.borderColor="red";
		altercontact.style.borderWidth="2px";
	       count=count+1;
	//return false;
	}


	mailformat = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
	if(email.value.match(mailformat))
	{
	//return true;
	}
	else
	{
	//alert("You have entered an invalid email address!");
	//email.focus();
		email.style.borderColor="red";
		email.style.borderWidth="2px";
	       count=count+1;
	//return false;
	}


	if(count==0)
	       {
		
		//alert("Fill the  details");
	       return true;
	       }
	else
	       {
		if(count==1)
	       alert("Please update the highlighted mandatory field.");
		else 
			alert("Please update the highlighted mandatory fields.");
	       return false;
	       }

}

	
