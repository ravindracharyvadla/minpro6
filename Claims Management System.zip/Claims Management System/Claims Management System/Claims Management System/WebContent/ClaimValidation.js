

function formValidation() {
	var id = document.registration.claimID;
	var id1 = document.registration.memberID;
	var ClaimServiceDate= document.registration.claimServiceDate;
	var ClaimSubmissionDate = document.registration.claimSubmissionDate;
	var ClaimProcessingDate = document.registration.claimProcessingDate;
	var Claimstatus = document.registration.claimstatus;
	var ClaimAmount = document.registration.claimAmount;
	var ApprovedAmount = document.registration.approvedAmount;
	
	
	var count;
	count=0;
	var check;
	
	
	check=/^[0-9]+$/;
	if (id.value.match(check))
	{
	}
	else
	{
	//alert("AdminId should contains Number");
	//fname.focus();
		id.style.borderColor="red";
		id.style.borderWidth="2px";
	count=count+1;
	//return false;
	}
	
	
	check=/^[0-9]+$/;
	if (id1.value.match(check))
	{
	}
	else
	{
	//alert("AdminId should contains Number");
	//fname.focus();
		id1.style.borderColor="red";
		id1.style.borderWidth="2px";
	count=count+1;
	//return false;
	}
	
	

	check=/^([0-9]{2})\/([0-9]{2})\/([0-9]{4})$/;
	if (ClaimServiceDate.value.match(check))
	{
	}
	else
	{
	//alert("First name should contains character");
	//fname.focus();
		ClaimServiceDate.style.borderColor="red";
		ClaimServiceDate.style.borderWidth="2px";
	count=count+1;
	//return false;
	}
	 
	

	check=/^([0-9]{2})\/([0-9]{2})\/([0-9]{4})$/;
	if (ClaimSubmissionDate.value.match(check))
	{
	}
	else
	{
	//alert("First name should contains character");
	//fname.focus();
		ClaimSubmissionDate.style.borderColor="red";
		ClaimSubmissionDate.style.borderWidth="2px";
	count=count+1;
	//return false;
	}
	
	
	

	check=/^([0-9]{2})\/([0-9]{2})\/([0-9]{4})$/;
	if (ClaimProcessingDate.value.match(check))
	{
	}
	else
	{
	//alert("First name should contains character");
	//fname.focus();
		ClaimProcessingDate.style.borderColor="red";
		ClaimProcessingDate.style.borderWidth="2px";
	count=count+1;
	//return false;
	}
	
	
	
	check=/^[A-Za-z]+$/;
	if (Claimstatus.value.match(check))
	{

	}
	else
	{
	//alert("First name should contains character");
	//fname.focus();
		Claimstatus.style.borderColor="red";
		Claimstatus.style.borderWidth="2px";
	count=count+1;
	//return false;
	}
	
	
	
	
	

	check=/^[0-9]+$/;
	if (ClaimAmount.value.match(check))
	{
	       //return true;
		//document.write(contact.length);
	}
	
	else
	{
	
	//num.focus();
		//alert("Contact must contain number");
		ClaimAmount.style.borderColor="red";
		ClaimAmount.style.borderWidth="2px";
	       count=count+1;
	//return false;
	}
	
	

	check=/^[0-9]+$/;
	if (ApprovedAmount.value.match(check))
	{
	       //return true;
	}
	else
	{
	//alert("Age must contain number");
	//age.focus();
		ApprovedAmount.style.borderColor="red";
		ApprovedAmount.style.borderWidth="2px";
	       count=count+1;
	//return false;
	}

	
	
	if(count==0)
	       {
		
		//alert("Fill the  details");
	       return true;
	       }
	else
	       {
		if(count==1)
	       alert("Please update the highlighted mandatory field.");
		else 
			alert("Please update the highlighted mandatory fields.");
	       return false;
	       }

}

	
